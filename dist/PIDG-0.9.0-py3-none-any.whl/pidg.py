__author__ = "Benoit CAYLA"
__email__ = "benoit@datacorner.fr"
__license__ = "MIT"

from pidg import main

if __name__ == "__main__":
	main()